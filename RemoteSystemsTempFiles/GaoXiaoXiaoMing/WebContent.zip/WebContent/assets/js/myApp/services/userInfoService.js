/**
 * Created by Govern on 2016/9/13.
 */
angular.module('xiaoMing').service('userInfoService',['$rootScope','$http','$state',function ($rootScope, $http, $state) {
    /**
     * 初始化
     */
    //保存当前作用域
    var that=this;
    //初始化contacts和phoneNumber数据
    this.postData={
        phoneNumber:'',
        position:''
    };
    var postData={
        phoneNumber:'',
        position:''
    };
    console.log(postData);
    //学校列表
    this.univList=[];
    //校区列表
    this.campusList=[];
    //年级列表
    this.gradeList=[];
    //部门列表
    this.departList=[];

    /**
     * 获得默认数据
     */
    //请求数据
    this.getUserData=function () {
        $http({
            method:'POST',
            url:'userInfo_show.action',
            cache:true
            //statue:200~299
        }).success(function (data, status, header, config) {
            //清空
            that.postData={};
            //获取数据
            if(data.status=='true'){
                console.log(data);
                //向下传播到各个子级
                $rootScope.$broadcast('getUserData',data);
                //获得contacts和phoneNumber数据
                that.postData.phoneNumber=data.phoneNumber;
                that.postData.position=data.position;
                //获取数据失败时
            }else if(data.status=='false'){
                $state.go('login');
            }
            //响应失败时
        }).error(function (data, status, header, config) {
            console.error('服务器繁忙，请稍后重试');
        })
    };

    /**
     * 获得下拉框选项数据
     */
    //获取学校列表
    this.getUniv=function () {
        $http({
            method:'POST',
            url:'university_list.action',
            cache:true
        }).success(function (data, status, header, config) {
            //清空
            that.univList=[];
            //接收数据
            if(data.status=='true'){
                that.univList=data;
                $rootScope.$broadcast('getUniv',that.univList);
            }
        }).error(function (data, status, header, config) {
            console.error('服务器繁忙，请稍后重试');
        })
    };
    //获取校区列表
    this.getCampus=function () {
        $http({
            method:'POST',
            url:'university_campus.action',
            cache:true,
            data:JSON.stringify({
                "id":1
            })
        }).success(function (data, status, header, config) {
            //清空
            that.campusList=[];
            //接收数据
            if(data.status=='true'){
                that.campusList=data.data;
                $rootScope.$broadcast('getCampus',that.campusList);
            }
        }).error(function (data, status, header, config) {
            console.error('服务器繁忙，请稍后重试');
        })
    };
    //获取年级列表
    this.getGrade=function () {
        $http({
            method:'POST',
            url:'university_grade.action',
            cache:true
        }).success(function (data, status, header, config) {
            //清空
            that.gradeList=[];
            //接收数据
            if(data.status=='true'){
                that.gradeList=data.data;
                $rootScope.$broadcast('getGrade',that.gradeList);
            }
        }).error(function (data, status, header, config) {
            console.error('服务器繁忙，请稍后重试');
        })
    };
    //获取当前组织的部门列表
    this.getDepart=function () {
        $http({
            method:'POST',
            url:'department_list.action',
            cache:true
        }).success(function (data, status, header, config) {
            //清空
            that.departList=[];
            //接收数据
            if(data.status=='true'){
                that.departList=data.data;
                $rootScope.$broadcast('getDepart',that.departList);
            }
        }).error(function (data, status, header, config) {
            console.error('服务器繁忙，请稍后重试');
        })
    };

    /**
     * 动态触发ajax发送数据给后台
     */
    //转换为Id
    this.changeAsId=function (nameList,changeObj) {
        var Id;
        angular.forEach(nameList,function (value,key) {
            if(value.name==changeObj){
                Id=value.id;
            }
            return;
        });
        return Id;
    };
    //ng-focus时复制的模板,用作对照
    var init;
    this.initData=function (initData) {
        init=initData;
    };
    //获取到当前input的value值
    this.getValue=function (inputName) {
        return value=document.getElementById(inputName).value;
    };
    //ng-blur时进行对照，若有修改，则发送请求
    this.newData=function (DataName,newData) {
        var oneOfTwoKey=false;
        //查询对照post内容是否含有两个必要key
        //注意此处形参中value与key反了
        angular.forEach(that.postData,function (value,key) {
            //如果有修改
            if(newData!==init){
                //如果是两个必要key
                if(key===DataName){
                    //发送修改
                    that.sendUserData(that.postData);
                    //表明是两种情况的第一种情况，则无需判断第二种情况
                    oneOfTwoKey=true;
                }
            }
        });
        if(oneOfTwoKey===false){
            //初始化(一定包含position和phoneNumber)
            that.postData=postData;
            //加上可选的修改数据
            that.postData[DataName]=newData;
            that.sendUserData(that.postData);
            console.log(that.postData);
        }

    };
    //动态发送数据
    this.sendUserData=function (data) {
        $http({
            method:'POST',
            url:'userInfo_update.action',
            //data对象的格式
            dataType:'json',
            data:JSON.stringify(data)
        }).success(function (data, status, header, config) {
            if(data.status=='true'){
                console.info('修改成功');
            }else if(data.status=='false'){
                console.info('修改失败');
            }
        }).error(function (data, status, header, config) {
            console.log('服务器繁忙，请稍后重试');
        })
    };
}]);