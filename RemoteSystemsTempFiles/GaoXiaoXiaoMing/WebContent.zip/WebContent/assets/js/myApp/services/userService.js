angular.module('xiaoMing')
.service("userService", ["$rootScope","$http", "$state", function($rootScope, $http, $state){
    var self = this;
    
    //表单校验
    this.formValidate = function(){
        if($.fn.validate){
            $('#login-form').validate({
                rules: {
                    "account": {
                        required: true
                    },
                    "password": {
                        required: true
                    },
                    //  randomCode: {
                    //      required: true
                    //  }
                },
                messages: {
                    "account": {
                        required: '请输入帐号'
                    },
                    "password": {
                        required: '请输入密码'
                    },
                    // "randomCode": {
                    //     required: '请再输入一次密码'
                    // }
                },
                debug: true
            });   
        }
    };
    
    //登陆
    this.login = function(loginName, password, rdCode){
        var form = {
            loginName: "",
            code: "",
            password: "" //暂定
        };
        /*暂时没有code*/
        if(!rdCode){
            rdCode = "";
        }
        /*暂时没有code*/
        if(!loginName||!password){
            return
        }
        form = {
            loginName: loginName,
            code: rdCode,
            password: $.md5(password) //暂定
        };
        $http({
            method: "POST",
            url: "user_login.action",
            dataType:"json", 
            data: JSON.stringify(form)
        }).success(function(res, status, headers, config){
            if("true" == res.status){  
                //设置1小时cookie
                var deadline = new Date();
                deadline.setHours(deadline.getHours() + 1);
                document.cookie= "USER_INFO="+JSON.stringify(res)+";expires="+deadline.toGMTString();
                //保存用户信息到全局作用域
                $rootScope.user = res;
                //在localStorage保存用户类型
                localStorage.setItem('role',res.role);
                $state.go("main.home");
            }else if(res.status == "false" && res.error == "accountpassword"){
                console.error("密码错了锁嗨");
            }  
        }).error(function(res, status, headers, config){
            console.error("未知错误");
        });
    };

    //用户信息未过期则不需要登陆自动跳转到首页
    this.autoLogin = function(){
        var userInfo = getCookie("USER_INFO");
        if(userInfo != null){
            $state.go("main.home");
        }
    };
    
    //注销
    this.logout = function(){
        $http({
            method: "POST",
            url: "user_logout.action"
        }).success(function(res, status, headers, config){
             removeCookie("USER_INFO");
             $state.go("login",{},{reload:true});
             window.location.reload();
        }).error(function(res, status, headers, config){
            console.error("未知错误");
        });
    };
    
    //获取未读消息
    this.getUnread = function(org_id){
        var data = {id: ""};
        if(org_id){
            data.id = org_id;
        }
        $http({
            method : "POST",
            url : 'unread_query.action',
            data : JSON.stringify(data)
        }).success(function(res, status, headers, config){
            if(res.status == "true"){
                $rootScope.$broadcast("getUnread", res);
            }else if(res.status == "false" && res.error == "noLogin"){
                removeCookie("USER_INFO");
                $state.go('login');
            }
        }).error(function(res, status, headers, config){
            console.error("服务器繁忙，请稍后重试");
        });
    };

    //保存皮肤设定
    this.skinList = [
        "url('assets/img/bg5.jpg')no-repeat center center fixed",
        "url('assets/img/bg2.jpg')no-repeat center center fixed",
        "url('assets/img/bg.jpg')no-repeat top center fixed",
        "url('assets/img/giftly.png')repeat",
        "#2c3e50",
        "url('assets/img/bg3.png')repeat",
        "url('assets/img/bg8.jpg')no-repeat center center fixed",
        "url('assets/img/bg9.jpg')no-repeat center center fixed",
        "url('assets/img/bg10.jpg')no-repeat center center fixed",
        "url('assets/img/bg11.jpg')no-repeat center center fixed",
        "url('assets/img/bg12.jpg')no-repeat center center fixed",
        "url('assets/img/bg13.jpg')repeat"
    ]
    this.setSkin = function(id){
        var userInfo = getCookie("USER_INFO");
        if(!userInfo)return
        if(!id && arguments.length == 0){
            var curBg = localStorage.getItem("custom_bg_"+userInfo.phoneNumber);
            if(curBg){
                $("body").css({
                    "background": self.skinList[curBg] 
                }); 
            }else{
                $("body").css({
                    "background": self.skinList[2] 
                });
            }
        }else{
            localStorage.setItem("custom_bg_"+userInfo.phoneNumber, id);
            $("body").css({
                "background": self.skinList[id]
            });
        }
    };

    
}]);