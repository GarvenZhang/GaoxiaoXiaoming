/**
 * Created by Govern on 2016/9/12.
 */
angular.module('xiaoMing').service('orgInfoService',['$rootScope','$http','$state',function ($rootScope,$http,$state) {
    /**
     * 请求默认数据
     */
    this.getOrgInfo=function () {
        $http({
            method:'POST',
            url:'organization_info.action'
        }).success(function (data, status, header, config) {
            //status:200~299
            console.log(data);
            if(data.status=='true'&&data.university){
                //广播给所有子级scope
                $rootScope.$broadcast('getInfoData',data);
            }else if (data.status=='false'&&data.errorMessage){
                $state.go('login');
            }
        }).error(function (data, status, header, config) {
            //响应失败
            console.error('服务器繁忙，请稍后再试！')
        });
    };

    /**
     * 请求下拉框数据
     */
    this.getUniv=function () {
        $http({
            method:'POST',
            url:'university_list.action'
        }).success(function (data, status, header, config) {
            if(data.status=='true'){
                $rootScope.$broadcast('getUniv',data.data);
            }else if(data.status=='false'){
                $state.go('login');
            }
        }).error(function (data, status, header, config) {
            console.log('服务器繁忙，请稍后再试！');
        })
    };

    /**
     * 发送修改请求
     */
}]);