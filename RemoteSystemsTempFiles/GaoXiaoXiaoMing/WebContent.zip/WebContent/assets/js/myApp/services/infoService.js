/**
 * Created by Govern on 2016/9/14.
 */
angular.module('xiaoMing').service('infoService',['$rootScope','$http','$state',function ($rootScope, $http, $state) {
    //接收后台数据,传给service
    var infoData={
        list:[],

    }

}]);
