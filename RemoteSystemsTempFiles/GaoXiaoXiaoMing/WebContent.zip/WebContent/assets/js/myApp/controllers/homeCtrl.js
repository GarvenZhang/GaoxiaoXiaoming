angular.module('xiaoMing').controller('homeCtrl', ['$scope','logService', function($scope, logService){
    
    //logService.getLogList(1,1);
    
}]);