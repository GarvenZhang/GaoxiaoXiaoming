angular.module('xiaoMing').controller('mainCtrl', ['$rootScope', '$scope','userService', function($rootScope, $scope, userService){
    var self = this;

    //用户信息
    this.user = getCookie("USER_INFO");

    //未读消息
    this.unreadList = {};
    userService.getUnread();
    $scope.$on("getUnread", function(state, data){
        self.unreadList = data;
    })

    //皮肤
    this.skinList = userService.skinList;
    this.setSkin = userService.setSkin;
    this.setSkin();
    
    //注销
    this.logout = userService.logout;
    
}]);