/**
 * Created by Govern on 2016/9/14.
 */
angular.module('xiaoMing').controller('$scope','infoService',function ($scope, infoService) {
    //保存当前作用域
    var that=this;
    //后台数据
    this.infocCtrl=[];
    //

});