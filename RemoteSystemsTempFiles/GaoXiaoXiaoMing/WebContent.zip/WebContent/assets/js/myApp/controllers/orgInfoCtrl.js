/**
 * Created by Govern on 2016/9/12.
 */
angular.module('xiaoMing').controller('orgInfoCtrl',['$scope','orgInfoService',function ($scope, orgInfoService) {
    //保存当前作用域
    var that=this;
    /**
     * 请求默认数据
     */
    //提供给view的后端数据
    this.infoData={};
    //初次请求
    orgInfoService.getOrgInfo();
    //动态监听并改变数据
    $scope.$on('getInfoData',function (event, data) {
        that.infoData=data;
        console.log(data);
    });

    /**
     * 请求下拉框数据
     */
    this.getUniv=function () {
        that.univData=[];
        that.getUniv=orgInfoService.getUniv();
        $scope.$on('getUniv',function (event, data) {
            that.univData=data;
        });
    };

    /**
     * 发送修改数据请求
     */


}]);