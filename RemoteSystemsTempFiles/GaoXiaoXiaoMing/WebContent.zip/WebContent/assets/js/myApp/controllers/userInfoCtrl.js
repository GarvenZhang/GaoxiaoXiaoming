/**
 * Created by Govern on 2016/9/13.
 */
angular.module('xiaoMing').controller('userInfoCtrl',['$scope','userInfoService',function ($scope, userInfoService) {
    //保存当前作用域
    var that =this ;
    //存储后台数据与view接应
    this.userData={};
    //初次请求数据
    userInfoService.getUserData ();
    //动态监听并接收数据
    $scope.$on('getUserData',function (event, data) {
        that.userData=data;
    });
    //动态监听并修改数据
    this.initData=userInfoService.initData;
    this.newData=userInfoService.newData;
    //获取表单value
    this.getValue=userInfoService.getValue;
    //转换为Id
    this.changeAsId=userInfoService.changeAsId;

    /**
     * 获得下拉框选项数据
     */
    //学校列表
    this.getUnivData=function () {
        this.univList=[];
        this.getUniv=userInfoService.getUniv();
        $scope.$on('getUniv',function (event, data) {
            that.univList=data.data;
        });
    }();
    //校区列表
    this.getCampusData=function () {
        console.log(1);
        this.campusList=[];
        this.getCampus=userInfoService.getCampus(); /*this.changeAsId(that.univList,that.userData.university)*/
        $scope.$on('getCampus',function (event, data) {
            that.campusList=data;
            console.log(that.campusList);
            //默认
            //that.defaultCampus=that.changeAsId(that.campusList,that.userData.campus);
        });

    };
    //年级列表
    this.getGradeData=function () {
        this.gradeList=[];
        this.getGrade=userInfoService.getGrade();
        $scope.$on('getGrade',function (event, data) {
            that.gradeList=data;
            //默认
            //that.defaultGrade=that.changeAsId(that.gradeList,that.userData.grade);
        });
    }();
    //当前机构部门列表
    this.getDepartData=function () {
        this.departList=[];
        this.getDepart=userInfoService.getDepart();
        $scope.$on('getDepart',function (event, data) {
            that.departList=data;
            //默认
            //that.defaultDepart=that.changeAsId(that.departList,that.userData.department);
        });
    }();


}]);