// angular.module('xiaoMing', ['ngRoute'])
//     .directive('sideBar',function() {
//         if(localStorage.getItem("role")=="admin"){
//             return { 
//                 restrict: 'E', 
//                 templateUrl: 'adminSideBar', 
//                 replace: true 
//             };
//         }else if(localStorage.getItem("role")=="member"){
//             return { 
//                 restrict: 'E', 
//                 templateUrl: 'memberSideBar', 
//                 replace: true 
//             };
//         }
        
//     });