angular.module('xiaoMing', ['ngRoute']).config(['$routeProvider',function($routeProvider){
    $routeProvider
        //member
        .when('/work',{
            templateUrl : '../../pages/member/desk/work.html',
            //controller : 
        })
        .when('/inform',{
            templateUrl : '../../pages/member/desk/inform.html',
            //controller : 
        })
        .when('/doc_m',{
            templateUrl : '../../pages/member/desk/doc.html',
            //controller : 
        })
        .when('/enroll',{
            templateUrl : '../../pages/member/desk/enroll.html',
            //controller : 
        })
        .when('/leave',{
            templateUrl : '../../pages/member/desk/leave.html',
            //controller : 
        })
        .when('/info_o',{
            templateUrl : '../../pages/member/organization/info.html',
            //controller : 
        })
        .when('/contact',{
            templateUrl : '../../pages/member/organization/contact.html',
            //controller : 
        })
        .when('/freetime_m',{
            templateUrl : '../../pages/member/organization/freetime.html',
            //controller : 
        })
        .when('/invite_m',{
            templateUrl : '../../pages/member/organization/invite.html',
            //controller : 
        })
        .when('/info_a',{
            templateUrl : '../../pages/member/account/info.html',
            //controller : 
        })
        .when('/message',{
            templateUrl : '../../pages/member/account/message.html',
            //controller : 
        })
        .when('/password_m',{
            templateUrl : '../../pages/member/account/password.html',
            //controller : 
        })
        .when('/log_m',{
            templateUrl : '../../pages/member/account/log.html',
            //controller : 
        })
        //admin
        .when('/staff',{
            templateUrl : '../../pages/admin/organization_admin/staff.html',
            //controller : 
        })
        .when('/materials',{
            templateUrl : '../../pages/admin/organization_admin/materials.html',
            //controller : 
        })
        .when('/doc_a',{
            templateUrl : '../../pages/admin/organization_admin/doc.html',
            //controller : 
        })
        .when('/freetime_a',{
            templateUrl : '../../pages/admin/organization_admin/freetime.html',
            //controller : 
        })
        .when('/organizations',{
            templateUrl : '../../pages/admin/organization_admin/organizations.html',
            //controller : 
        })
        .when('/statistics',{
            templateUrl : '../../pages/admin/organization_admin/statistics.html',
            //controller : 
        })
        .when('/invite_a',{
            templateUrl : '../../pages/admin/organization_admin/invite.html',
            //controller : 
        })
        .when('/org_trends',{
            templateUrl : '../../pages/admin/message/org_trends.html',
            //controller : 
        })
        .when('/sys_message',{
            templateUrl : '../../pages/admin/message/sys_message.html',
            //controller : 
        })
        .when('/letter',{
            templateUrl : '../../pages/admin/message/letter.html',
            //controller : 
        })
        .when('/info_a',{
            templateUrl : '../../pages/admin/account_admin/org_info.html',
            //controller : 
        })
        .when('/password_a',{
            templateUrl : '../../pages/admin/account_admin/password_admin.html',
            //controller : 
        })
        .when('/log_a',{
            templateUrl : '../../pages/admin/account_admin/log.html',
            //controller : 
        })
        //other
        .when('/',{
            templateUrl : '../../pages/other/home.html',
            //controller : 
        })
}])
//侧栏，权限控制
.directive('sideBar',function() {
    if(localStorage.getItem("role")=="admin"){
        return { 
            restrict: 'E', 
            templateUrl: 'adminSideBar', 
            replace: true 
        };
    }else if(localStorage.getItem("role")=="member"){
        return { 
            restrict: 'E', 
            templateUrl: 'memberSideBar', 
            replace: true 
        };
    }
    
});