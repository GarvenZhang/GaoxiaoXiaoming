;$(function(){
    
    $('.login-role button').click(function(){
        $('.login-role button').removeClass('active');
        $(this).addClass("active");
    });
    
    //login
    $('.login-btn').click(function(){
        //临时权限控制
        if($('.login-role .active').attr('value')=="admin"){
            localStorage.setItem("role","admin");
        }else{
            localStorage.setItem("role","member");
        }
        
    });
    
});